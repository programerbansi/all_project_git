import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';

const getLocalItems=()=>{
  let list=localStorage.getItem('lists');
  console.log(list);
  if(list)
  {
    return JSON.parse(list);
  }
  else{
    return [];
  }
}

function App() {
    
    const[data,setData]=useState(getLocalItems());
    const[toggle,setToggle]=useState(true);
    const[id,setId]=useState("");
    const[name,setName]=useState("");
    const[price,setPrice]=useState("");
    const[brand,setBrand]=useState("");
    const[des,setDes]=useState("");
    const[isindex,setIsindex]=useState("");
    const[isedit,setIsedit]=useState(false);
    const btn_click=(e)=>{
       e.preventDefault();
       if(isedit)
       {
          console.log(isindex);
          var tmpdata=data;
          tmpdata[isindex].id=id;
          tmpdata[isindex].name=name;
          tmpdata[isindex].price=price;
          tmpdata[isindex].brand=brand;
          tmpdata[isindex].des=des;
          setData(tmpdata);
          setToggle(true);
          setIsindex("");
          setIsedit(false);
       }
       else
       {
       setData([...data,{
        id:id,
        name:name,
        price:price,
        brand:brand,
        des:des,
       }]); 
      }

       setBrand("");
       setId("");
       setName("");
       setPrice("");
       setDes("");
     
    }
    const handleEdit=(index)=>{
      setIsindex(index);
      setIsedit(true)
      const editdata=data.find((item,i)=>{
        return i===index;
      })
      setToggle(false);
      console.log(editdata);
      setId(editdata.id);
      setName(editdata.name);
      setPrice(editdata.price);
      setBrand(editdata.brand);
      setDes(editdata.des);
        
    }
    const handleDelete=(index)=>{

       const new_data=data.filter((item,i)=>{
        return index!=i;
       })
       setData(new_data);
    }
    useEffect(()=>{
      localStorage.setItem('lists',JSON.stringify(data))
    },[data])
  return (
   <div>
    <form>
      Id: <input type="text" value={id} onChange={(e)=>setId(e.target.value)}></input><br></br>
      Name:<input type="text" value={name} onChange={(e)=>setName(e.target.value)}></input><br></br>
      Price:<input type="text" value={price} onChange={(e)=>setPrice(e.target.value)}></input><br></br>
      Brand:<input type="text" value={brand} onChange={(e)=>setBrand(e.target.value)}></input><br></br>
      Description:<input type="text" value={des} onChange={(e)=>setDes(e.target.value)}></input><br></br>
      {toggle?<input type="submit" onClick={btn_click} value="ADD"></input>:<input type="submit" onClick={btn_click} value="Update"></input>}

    </form>
    <div>
      <table border={1}>
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Price</th>
            <th>Brand</th>
            <th>Description</th>
            <th></th>
          </tr>
        </thead>
    {
      data.map((item,index)=>(
          <tbody>
           <tr>
            <td>{item.id}</td>
            <td>{item.name}</td>
            <td>{item.price}</td>
            <td>{item.brand}</td>
            <td>{item.des}</td>
            <td><button onClick={()=>handleEdit(index)}>Edit</button>
            <button onClick={()=>handleDelete(index)}>Delete</button></td>
           </tr>
           </tbody>
      ))
    }
    </table>
    </div>
    
   </div>
  );
}

export default App;
