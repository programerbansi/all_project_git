import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AddProduct } from '../redux/Actions';
import Button from '@mui/material/Button';
import { useForm } from 'react-hook-form';
import classNames from 'classnames';
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

function Home() {

    const { register, handleSubmit, formState: { errors }, reset } = useForm({ mode: 'onTouched' });
    console.log(errors, 'Errors......');

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const onsell = 0;
    const category_id = 1;
    const sub_category_id = 1;
    const brand_id = 1;

    const onSubmit = (data) => {
        console.log(data);
        const formdata = new FormData();
        formdata.append('product_name', data.pname);
        formdata.append('price', data.price);
        formdata.append('onsell', onsell);
        formdata.append('category_id', category_id);
        formdata.append('sub_category_id', sub_category_id);
        formdata.append('brand_id', brand_id);
        for (let i = 0; i < data.image.length; i++) {
            formdata.append(`image[${i}]`, data.image[i])
        }
        reset();
        toast.success("Product added sucessfully!");
        dispatch(AddProduct(formdata));
    }

    return (
        <div>
            <div className="container">
                <div className='mb-5 pb-5'>
                    <section className="content">
                        <div className="container-fluid pt-5">
                            <div className="row justify-content-center">
                                <div className="col-md-6">
                                    <div className="card card-primary">
                                        <div className="card-header">
                                            <h3 className="card-title">ADD PRODUCT</h3>
                                        </div>
                                        <form encType="multipart/form-data" onSubmit={handleSubmit(onSubmit)}>
                                            <div className="card-body">
                                                <div className="form-group text-start mb-3">
                                                    <label htmlFor="pname">Product Name</label>
                                                    <input type="text" className={classNames("form-control", { 'is-invalid': errors.pname })} id="pname" placeholder="Product Name"
                                                        {...register("pname", {
                                                            required: '** This field is required !!',
                                                            minLength: {
                                                                value: 2,
                                                                message: '** Product Name requires atleast 2 characters !!'
                                                            }
                                                        })}
                                                    />
                                                    {errors.pname && (<span className='text-danger form-text invalid-feedback'>{errors.pname.message}</span>)}
                                                </div>
                                                <div className="form-group text-start mb-3">
                                                    <label htmlFor="price">Price</label>
                                                    <input className={classNames("form-control", { 'is-invalid': errors.price })} id="price" placeholder="Price" name='price'
                                                        {...register("price", {
                                                            required: '** This field is required !!',
                                                            pattern: {
                                                                value: /\d+$/,
                                                                message: '** Price should only containe numbers!!'
                                                            }
                                                        })} />
                                                    {errors.price && (<span className='text-danger form-text invalid-feedback'>{errors.price.message}</span>)}
                                                </div>
                                                <div className="form-group text-start mb-3">
                                                    <div className="input-group">
                                                        <div className="mb-3 ">
                                                            <label htmlFor="image" className="form-label">Image</label>
                                                            <input type="file" multiple id="image" className={classNames("form-control", { 'is-invalid': errors.image })} name='image'
                                                                {...register("image", {
                                                                    required: '** Please select atleast one image-file!!',
                                                                })} />
                                                            {errors.image && (<span className='text-danger form-text invalid-feedback'>{errors.image.message}</span>)}
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="card-footer">
                                                <ToastContainer />
                                                <Button variant="outlined" type='submit'>Submit</Button>
                                                <Button variant="outlined" onClick={() => navigate('/viewProduct')} className="ms-2">View Product List</Button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    )
}

export default Home

// onClick={() => dispatch(AddProduct(formdata), setPrice(''), setName(''), document.getElementById('imageFile').value='')}