import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import '../Css-style/viewProductStyle.css';

import { styled } from '@mui/material/styles';
import Button from '@mui/material/Button';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { EditProduct, LoadProduct, DeleteProduct } from '../redux/Actions/index';

function ViewProduct() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const products = useSelector((state) => state.crudReducer.products);

    useEffect(() => {
        dispatch(LoadProduct());
    }, [dispatch])

    const [foundProducts, setfoundProducts] = useState(products);
    const [filterName, setFilterName] = useState('');

    const [name, setName] = useState('');
    const [price, setPrice] = useState('');
    const [image, setImage] = useState('');
    const [edit, setEdit] = useState(false)
    const [id, setId] = useState();
    const onsell = 0;
    const category_id = 1;
    const sub_category_id = 1;
    const brand_id = 1;

    let obj = { product_name: name, price: price, image: image, id: id, onsell: onsell, category_id: category_id, sub_category_id: sub_category_id, brand_id: brand_id }
    const handleEdit = (item) => {
        setEdit(true);
        setName(item.product_name);
        setPrice(item.price);
        setImage(item.image);
        setId(item.id);
    }

    const StyledTableCell = styled(TableCell)(({ theme }) => ({
        [`&.${tableCellClasses.head}`]: {
            backgroundColor: theme.palette.common.black,
            color: theme.palette.common.white,
        },
        [`&.${tableCellClasses.body}`]: {
            fontSize: 14,
        },
    }));

    const StyledTableRow = styled(TableRow)(({ theme }) => ({
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.action.hover,
        },
        '&:last-child td, &:last-child th': {
            border: 0,
        },
    }));

    const filter = (e) => {
        const keyword = e.target.value;
        if (keyword !== '') {
            const results = products.filter((product) => {
                return product.product_name.toLowerCase().startsWith(keyword.toLowerCase());
            });
            setfoundProducts(results);
        } else {
            setfoundProducts(products);
        }
        setFilterName(keyword);
    };

    return (
        <div>
            {
                !edit ?
                    <div className="container mt-4 mb-3">
                        <input
                            type="search"
                            value={filterName}
                            onChange={filter}
                            className="search form-control mb-3"
                            placeholder="Search"
                        />
                        <TableContainer component={Paper}>
                            <Table sx={{ minWidth: 700 }} aria-label="customized table">
                                <TableHead>
                                    <TableRow>
                                        <StyledTableCell align="center">Poduct Name</StyledTableCell>
                                        <StyledTableCell align="center">Image</StyledTableCell>
                                        <StyledTableCell align="center">Price</StyledTableCell>
                                        <StyledTableCell align="center">Category_Id</StyledTableCell>
                                        <StyledTableCell align="center">Sub_Category_Id</StyledTableCell>
                                        <StyledTableCell align="center">Brand_Id</StyledTableCell>
                                        <StyledTableCell align="center">Actions</StyledTableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {foundProducts && foundProducts.length > 0 ? (
                                        foundProducts.map((item, index) => (
                                            <StyledTableRow key={index}>
                                                <StyledTableCell align="center">{item.product_name}</StyledTableCell>
                                                <StyledTableCell align="center">{
                                                    item.product_images.map((item, index) => {
                                                        return (<span key={index}><span className='m-3'>{item.image}</span><br /></span>)
                                                    })
                                                }</StyledTableCell>
                                                <StyledTableCell align="center">{item.price}</StyledTableCell>
                                                <StyledTableCell align="center">{item.category_id}</StyledTableCell>
                                                <StyledTableCell align="center">{item.sub_category_id}</StyledTableCell>
                                                <StyledTableCell align="center">{item.brand_id}</StyledTableCell>
                                                <StyledTableCell align="center">
                                                    <Button variant="outlined" onClick={() => handleEdit(item)} className='me-2'>Edit</Button>
                                                    <Button variant="outlined" color="error" onClick={() => dispatch(DeleteProduct(item.id))} className='ms-2'>Delete</Button>
                                                </StyledTableCell>
                                            </StyledTableRow>
                                        ))
                                    ) : (
                                        products.map((item, index) => (
                                            <StyledTableRow key={index}>
                                                <StyledTableCell align="center">{item.product_name}</StyledTableCell>
                                                <StyledTableCell align="center">{
                                                    item.product_images.map((item, index) => {
                                                        return (<span key={index}><span className='m-3'>{item.image}</span><br /></span>)
                                                    })
                                                }</StyledTableCell>
                                                <StyledTableCell align="center">{item.price}</StyledTableCell>
                                                <StyledTableCell align="center">{item.category_id}</StyledTableCell>
                                                <StyledTableCell align="center">{item.sub_category_id}</StyledTableCell>
                                                <StyledTableCell align="center">{item.brand_id}</StyledTableCell>
                                                <StyledTableCell align="center">
                                                    <Button variant="outlined" onClick={() => handleEdit(item)} className='me-2'>Edit</Button>
                                                    <Button variant="outlined" color="error" onClick={() => dispatch(DeleteProduct(item.id))} className='ms-2'>Delete</Button>
                                                </StyledTableCell>
                                            </StyledTableRow>
                                        ))
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                        <Button variant="outlined" onClick={() => navigate('/')} className='mt-3'>ADD NEW PRODUCT</Button>
                    </div> :
                    <div className="container">
                        <div className='mb-5 pb-5'>
                            <section className="content">
                                <div className="container-fluid pt-5">
                                    <div className="row justify-content-center">
                                        <div className="col-md-6">
                                            <div className="card card-primary">
                                                <div className="card-header">
                                                    <h3 className="card-title">{
                                                        edit ? 'Edit Product' : 'Add Product'
                                                    }</h3>
                                                </div>
                                                <form encType="multipart/form-data">
                                                    <div className="card-body">
                                                        <div className="form-group text-start mb-3">
                                                            <label htmlFor="name">Product Name</label>
                                                            <input type="text" className="form-control" id="name" placeholder="Enter name" value={name}
                                                                onChange={(e) => setName(e.target.value)}
                                                            />
                                                        </div>
                                                        <div className="form-group text-start mb-3">
                                                            <label htmlFor="detail">Price</label>
                                                            <input type="number" className="form-control" id="detail" placeholder="Price"
                                                                value={price}
                                                                onChange={(e) => setPrice(e.target.value)} />
                                                        </div>
                                                        <div className="form-group text-start mb-3">
                                                            <div className="input-group">
                                                                <div className="mb-3 ">
                                                                    <label htmlFor="imageFile" className="form-label">Image</label>
                                                                    <input className="form-control p-2" type="file" multiple id="imageFile" onChange={(e) => setImage(e.target.files)} />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="card-footer">
                                                        <button type="button" className="btn btn-primary me-2" onClick={() => dispatch(EditProduct(obj), setPrice(''), setName(''), document.getElementById('imageFile').value = '', toast("Product is updated successfully"))}>Update</button>
                                                        <button type="button" className="btn btn-primary ms-2" onClick={() => setEdit(false)}>View Product List</button>
                                                        <ToastContainer />
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                        </div>
                    </div>
            }
        </div>
    )
}

export default ViewProduct