import { client } from "./client";
const saveProduct = "save-product";
const getProducts ='get-product';
const editProduct ='edit-product';
const deleteProduct = 'delete-product?id=';

export const AddProduct = (obj)=>{
return {
    type:'ADD_PRODUCT',
    payload:client.post(saveProduct,obj)
}
}

export const LoadProduct = (currentPage) =>{
    return (dispatch)=>{
        client.get(`${getProducts}/?page=${currentPage}`).then((response)=>{
            console.log(response.data.data,'====response of get Product====');
            dispatch(GetProducts(response.data.data.data))
        }).catch((error)=>{
            console.log(error)
        })
    }
}
export const GetProducts = (products) =>{
    return {
        type:'GET_PRODUCTS',    
        payload:products
    }
}

export const EditProduct =(obj) =>{
    return (dispatch)=>{
        client.post(editProduct,obj).then(()=>{
            dispatch(LoadProduct());
            return {
                type:'EDIT_PRODUCT'
            }
        }).catch((error)=>{
            console.log(error);
        })
    }
}

export const DeleteProduct = (id) =>{
    return (dispatch)=>{
        client.post(`${deleteProduct}${id}`).then(()=>{
            dispatch(LoadProduct())
            return {
                type:'DELETE_PRODUCT'
            }
        }).catch((error)=>{
            console.log(error);
        })
    }
}

export const Pages = (page)=>{
    return {
        type:'CURRENT_ PAGE',
        payload:page
    }
}

export const TotalPages = (totalPage) =>{
    return {
        type:'TOTAL_PAGES',
        payload:totalPage
    }
}