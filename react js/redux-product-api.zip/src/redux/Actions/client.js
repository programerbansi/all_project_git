import axios from 'axios';

export const client = axios.create(
    {
        baseURL: "http://127.0.0.1:8000/api/admin/",
        headers: {
            "Content-Type": "multipart/form-data",
            "Authorization": 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiZDNhMWY0MGYzNDk5ZmZkZmUzMjI5ZDU3ODdiMWNkMTA5ZTYyZGFhOTRlZmQ4NGY4YzljZjE3NzQxN2U2ZTAzY2U4ZjY2MDZhNDQ5NTU3ZGEiLCJpYXQiOjE2NTY1ODI3MDEuMDg0OTA0LCJuYmYiOjE2NTY1ODI3MDEuMDg0OTA2LCJleHAiOjE2ODgxMTg3MDEuMDc5ODc2LCJzdWIiOiIyIiwic2NvcGVzIjpbXX0.aiHUdwmXZQ5j9ZTFvA9Ca6OthvoIsaADWJB7zmRSWmjK3pX549eJ1mmhInWR2UKOgG-Riymwo4UhQuYYPzxAL4j0YBl7dHI73BTMXRGY0KJsHJ96UlPB2ovxjodGVDtGCedRYGqESQ_RcMkj4C6se8TiDiXfinJJTv-OrJjR_27RhQK00KKbxad0uBu_fzhpv_h48wRNVH0SdifyT5obq6RtUHJfpMo_TjyDZRminSdj05vDtEIqtQ8JcsJlMZ-Xf_Rw8Z5xyO5A7QhGMEk6UV7Q6fs_kr0esRBXkwJBDexseOxenYU1_unvZsSTDdtHJV84MZ3MNxsOasWI7X58ucGbGqGeUqurRkP109k0SOJyN-mlr8AuKcLzMtp7drHdByKkD7BUUnpkLCymP3GKeBr1EiQlyT-vf1mLigZCgrj3hs2km8qC4QGRc1r0smCpGdnDgqcoSeQ01yR5gBEMS0akR9_9GUedo7UiYi4A2yktFVClS5Il1RKPu3fCanxxPJKfzGdv98itG8OK3EjykfqQM3MddEeBqgHKnmC5zodOoD8KeKvYz1RzeHNdPMbrIBQ6T3RmVJ80CqV4g9D_ZfnUjBwjZsDcz17kAp1NAlGHNmnvnFVvMjuqGFPo6RMXWl2V3ChSh4hQDpuEu0uMh7FBRqdNVjDsSjygc-XnF9s'
        }
    }
)