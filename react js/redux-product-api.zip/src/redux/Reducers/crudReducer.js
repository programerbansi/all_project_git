let initialState = {
    products:[],
    current_page:1,
    total_pages:null
}

export const  crudReducer = (state=initialState,action) => {
    switch(action.type){
        case 'GET_PRODUCTS':
            return {
                ...state,products:action.payload
            }
        case 'EDIT_PRODUCT':
            return {...state}
        case 'DELETE_PRODUCT':
            return {...state}
        case 'CRRENT_PAGE':
            return {
                ...state,current_page : action.payload
            }
        case 'TOTAL_PAGES':
            return {
                ...state,total_pages:action.payload
            }
        default :
         return state
    }
}

