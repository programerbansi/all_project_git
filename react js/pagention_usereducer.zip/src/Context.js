import React, { useReducer } from "react";
import { useEffect } from "react";
import Search from "./Search";
import Reducer from "./Reducer";
const AppContext = React.createContext();


const initialState={
    isLoading:true,
    query:"CSS",
    nbPages:0,
    page:0,
    hits:[],
   
};
const AppProvider=({children})=>{

    const [state,dispatch]=useReducer(Reducer,initialState);
    let API= "http://hn.algolia.com/api/v1/search?"
    
    const fetchapidata=async(url)=>{
        dispatch({type:"SET_LOADING"});
        try{
            const res= await fetch(url);
            const data=await res.json();
            console.log(data);
            dispatch({
                type:"GET_STORIES",
                payload:{
                    hits:data.hits,
                    nbPages:data.nbPages,
                   
                }
            
            })
            // isLoading=false;

        }
        catch(error)
        {
            console.error();
        }
    }
    //search
    const handlesearch=(search)=>{
        dispatch({
            type:"SEARCH_QUERY",
            payload:search,
        })
    }
    const handleprev=(event)=>{
        event.preventDefault();
        dispatch({
            type: "PREV_PAGE",
        })
    }
    const handlenext=(event)=>{
        event.preventDefault();
        dispatch({
            type: "NEXT_PAGE",
        })
    }
    useEffect(()=>{
        fetchapidata(`${API}query=${state.query}&page=${state.page}`);
    },[state.query,state.page])


    return (
        <AppContext.Provider value={{...state,handlesearch,handlenext,handleprev}}>{children}</AppContext.Provider>
    )
}
export{AppContext,AppProvider};
