import { type } from "@testing-library/user-event/dist/type";

const Reducer=(state,action)=>{
    switch(action.type)
    {
        case "SET_STORIES":
            return{
                ...state,
                isLoading:true
            }
        case "GET_STORIES":
            return{
                ...state,
                hits:action.payload.hits,
                nbPages:action.payload.nbPages,
              
                isLoading: false,
            }
        case "SEARCH_QUERY":
            return{
                ...state,
                query:action.payload,
            }    
         case "PREV_PAGE":
            let no=state.page-1;
            if(no<=0)
            {
                no=0;
            }
           
            return{
                ...state,
                page: no,
               
            }   
        case "NEXT_PAGE":
            let no1=state.page+1;
            if(no1>=state.nbPages)
            {
                no1=0;
            }
            return{
                ...state,
                page: no1,
              
            }   
    }
    return state;
};
export default Reducer;