import React, { useContext } from 'react'
import { AppContext } from './Context'

const Search = () => {
  const {query,handlesearch}=useContext(AppContext);
  return (
    <div>
        <h1 style={{textAlign:"center"}}>News Website</h1>
        <form>
          <div>
            <input 
               type="text" 
               placeholder='search here ex. html'
               value={query} 
               onChange={(e)=>handlesearch(e.target.value)} style={{marginLeft:"580px",padding:"5px"}}>
            </input>
          </div>
        </form>
      
    </div>
  )
}

export default Search
