import logo from './logo.svg';
import './App.css';
import Search from './Search';
import Pagention from './Pagention';
import Stories from './Stories';
import{useContext} from 'react';
import React from 'react';
import { AppContext } from './Context';


function App() {


  return (
    <>
  
    <Search/>
    <Pagention/>
    <Stories/>

    </>
  );
}

export default App;
