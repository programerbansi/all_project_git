import React, { useContext, useEffect } from 'react'
import { AppContext } from './Context'
import './Stories.css';


const Stories = () => {
   
    const{hits,isLoading}=useContext(AppContext);   
    if(isLoading)
    {
      return(
        <>
        <h1>Loading...</h1>
        </>
      )
    }

  return (
     <>
   
    {
       
        hits.slice(0,5).map((item)=>{
          const {title,author,objectId,url,num_comments}=item;
            return (
            
            <div className='stories' key={objectId}>
               <div className='card' >
                    <h2>{title}</h2>
                    <p>By <span>{author}</span> | <span>{num_comments}</span> comments</p>
                 
                     <div className='card-button'>
                          <a href={url} target="_blank"> Read More</a>
                     </div>
                </div>  
           </div>
            
            )
     })
    }
     </>
  )
}

export default Stories

