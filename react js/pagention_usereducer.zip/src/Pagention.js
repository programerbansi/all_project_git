import React, { useContext } from 'react'
import { AppContext } from './Context'
import './Pagention.css'
const Pagention = () => {
  const{page,nbPages,handlenext,handleprev}=useContext(AppContext);
  return (
    <div>
      <form  className='page_btn'>
        <button onClick={handleprev} className="btn1">PREV</button>
        <p>{page + 1} of {nbPages}</p>
        <button onClick={handlenext} className="btn1">NEXT</button>
        
      </form>
    </div>
  )
}

export default Pagention
