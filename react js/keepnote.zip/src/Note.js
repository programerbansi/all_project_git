import './Note.css';
import {BsFillTrashFill} from 'react-icons/bs';
const Note=(props)=>{
    return(
        <>
        <div className='main-note'>
         <div className="note-div">
            <h3>{props.title}</h3>
            <br></br>
            <p>{props.content}</p>
            <button className='btn-del'><BsFillTrashFill/></button>
         </div>
         </div>
        </>
    )
}
export default Note