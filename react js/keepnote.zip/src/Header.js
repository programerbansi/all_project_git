import './Header.css';
import {FaStickyNote} from 'react-icons/fa';
const Header=()=>{
     return(
         <>
          <div className='header-1'>
            <h1>
            <FaStickyNote/>Keep Note</h1>
          </div>
         </>
     )
}
export default Header