import { useState } from 'react';
import {IoMdAddCircleOutline} from 'react-icons/io';
import './CreateNote.css';
const CreateNote=(props)=>{
const [note,setNote]=useState({
    title:"",
    content:"",
});

const InputEvent=(event)=>{
    // const value=event.target.value;
    // const name = event.target.name;
    // event.preventDefault();
      const {name,value}=event.target;
     
     setNote((prevData)=>{
         return { 
            ...prevData,
            [name]:value,
         }
     })
     console.log(note);
    
}

const addEvent=(event)=>{
    props.passNote(note);
    event.preventDefault();
}
    return(
        <>
         <div className='main-div'>
             <div>
             <form >
                 <input 
                 type="text" 
                 placeholder="Title" 
                 className='text-1' 
                 autoComplete='off'
                 value={note.title}
                 name="title"
                  onChange={InputEvent}></input><br></br>
                 <textarea 
                 rows="" 
                 cols="" 
                 value={note.content}
                 name="content"
                 placeholder="Write a note" 
                 className='text-2' 
                 onChange={InputEvent}></textarea><br></br>
                 <button className='btn-add' onClick={addEvent}><IoMdAddCircleOutline/></button>
             </form>
             </div>
         </div>
        </>
    )
}
export default CreateNote