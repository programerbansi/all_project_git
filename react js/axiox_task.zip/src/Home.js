import { useEffect, useState } from 'react';
import { Table } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
const axios = require('axios');
const Home = () => {
    const [data, setData] = useState([]);
    const [del, setDel] = useState();
    // const[id1,setId1]=useState("");
    const [title1, setTitle1] = useState("");
    const [editid, setEditid] = useState("");
    useEffect(() => {
        axios.get('https://jsonplaceholder.typicode.com/posts')
            .then(function (r) {
                console.log(r);
                setData(r.data);
            })
            .catch(function (error) {
                console.log(error);
            })
    }, [])

    const handleDelete = (index, id) => {
        data.splice(index, 1);
        setData([...data]);
        setDel(id);

        axios.delete(`https://jsonplaceholder.typicode.com/post${del}`)
            .then(function (r) {
                console.log(r);

            })
            .catch(function (error) {
                console.log(error);
            })
    }

    const handleEdit = (item, idd) => {

        console.log(item);
        console.log(item.id);
        console.log(item.title);
        // setId1(item.id);
        setTitle1(item.title);
        setEditid(idd);
    }

    const handlesubmit = (event) => {
        event.preventDefault();
        axios.put(`https://jsonplaceholder.typicode.com/posts/${editid}`, {
            id: editid,
            title: title1
        })
            .then(function (r) {
                console.log(r.data)
            })
            .catch(function (error) {
                console.log(error)
            })
        //  setId1("");
        setTitle1("");

    }
    return (
        <>
            {/* <table border={1}>
                {
                    data.map((item, index) => (
                        <tbody key={index}>
                            <tr>
                                <td>{item.id}</td>
                                <td>{item.title}</td>
                                {/* <td>{item.body}</td> */}
                                {/* <td><button onClick={() => handleEdit(item, item.id)}>Edit</button><button onClick={() => handleDelete(index, item.id)}>Delete</button></td>
                            </tr>
                        </tbody>
                    ))
                }
            </table> */}
            <Table striped bordered hover>
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Title</th>
                        <th>Opretion</th>

                    </tr>
                </thead>
                {
                data.map((item,index)=>(
                    <tbody key={index}>
                    <tr>
                        <td>{item.id}</td>
                        <td>{item.title}</td>
                        {/* <td>{item.body}</td> */}
                        <td><button onClick={() => handleEdit(item, item.id)}>Edit</button><button onClick={() => handleDelete(index, item.id)}>Delete</button></td>

                    </tr>

                </tbody>
                ))    
                
               }
            </Table>
            <div>
                <form>
                    {/* ID:<input type="text" value={id1} onChange={(e)=>setId1(e.target.value)}></input><br></br> */}
                    Title:<input type="text" value={title1} onChange={(e) => setTitle1(e.target.value)}></input><br></br>
                    <input type="submit" value="submit" onClick={handlesubmit}></input>
                </form>
            </div>

        </>
    )
}
export default Home