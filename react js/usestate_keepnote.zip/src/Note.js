import './Note.css';
import {BsFillTrashFill} from 'react-icons/bs';
const Note=(props)=>{
    const deleteNote=()=>{
        props.deleteItem(props.id);
    }
    return(
        <>
        <div className='main-note'>
         <div className="note-div">
            <h3>{props.title}</h3>
            <br></br>
            <p>{props.content}</p>
            <button className='btn-del' onClick={deleteNote}><BsFillTrashFill/></button>
         </div>
         </div>
        </>
    )
}
export default Note