import { useState } from 'react';
import {IoMdAddCircleOutline} from 'react-icons/io';
import './CreateNote.css';
const CreateNote=(props)=>{

const [expand,setExpand]=useState(false);

const [note,setNote]=useState({
    title:"",
    content:"",
});

const InputEvent=(event)=>{
    // const value=event.target.value;
    // const name = event.target.name;
      const {name,value}=event.target;
     
     setNote((prevData)=>{
         return { 
            ...prevData,
            [name]:value,
         }
     })
     console.log(note);
    
}

const addEvent=(event)=>{
    props.passNote(note);
    setNote({
        title:"",
        content:"",
    });
    event.preventDefault();

}
const expandIt=()=>{
    setExpand(true);
}
const backtonormal=()=>{
    setExpand(false);
}
    return(
        <>
         <div className='main-div'   onDoubleClick={backtonormal}>
             <div>
             <form >
                { expand ?
                 <input 
                 type="text" 
                 placeholder="Title" 
                 className='text-1' 
                 autoComplete='off'
                 value={note.title}
                 name="title"
                  onChange={InputEvent}>
                      </input>
                      :null}
                   <br></br>   
                 <textarea 
                 rows="" 
                 cols="" 
                 value={note.content}
                 name="content"
                 placeholder="Write a note" 
                 className='text-2' 
                 onChange={InputEvent}
                 onClick={expandIt}
               >
                 </textarea><br></br>
                 {
                     expand ?
                 <button className='btn-add' onClick={addEvent}><IoMdAddCircleOutline/></button> :null
                }
             </form>
             </div>
         </div>
        </>
    )
}
export default CreateNote