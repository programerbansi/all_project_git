import './Footer.css';
const Footer=()=>{
    const yr=new Date().getFullYear();
    return(
        <>
         <h4>Copyright @ {yr}</h4>
        </>
    )
}
export default Footer