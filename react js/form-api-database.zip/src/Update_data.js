import { Link,useParams, useNavigate} from "react-router-dom";
import { Button , Form} from 'react-bootstrap';
import { useEffect , useState} from 'react';
const Update_data=()=>{

    let { id } = useParams();

    const linkUrl = "/View_contact/"+id
    const navigate = useNavigate();
    // console.log(id)
      const [posts,setPosts] = useState([])
      const [nm,setNm]=useState()
      const [no,setNo]=useState()
      const [addr,setAddr]=useState()
  
      useEffect(()=>{
       
          fetch("http://bansiapp.atwebpages.com/select_data_update.php?id="+id)
            .then(res => res.json())
            .then(
              (r) => {
                console.log(r)
                setPosts(r)
                setNm(r.nm)
                setNo(r.no)
                setAddr(r.addr)
              },
              
            )
  
      
         },[])
  
         const btn_click=(event)=>{
         
          event.preventDefault();
         
  
           setNm('');
           setNo('');
           setAddr('');
  
           fetch("http://bansiapp.atwebpages.com/update_contact.php?id="+id, {
        
                  method: 'POST',
                  body: JSON.stringify({
                    id:id,
                    nm:nm,
                    no:no,
                    addr:addr,
                  }),
                  headers: {
                    'Content-type': 'application/json; charset=UTF-8',
                  },
                })
                  .then((response) => response.json())
                  .then((json) => {
                    // navigate('/View_contact/'+json.id_no);
                    console.log(json)
                  });
  
  
          
         }
  
         



    return(
        <>
      <div className='main-div'>
              <h3>Update Contacts</h3>
            <Form>
                
                <Form.Group className="mb-3" >
                    <Form.Label>Name</Form.Label>
                    <Form.Control id="t1" type="text" placeholder="Enter Name" value={nm} onChange={(t)=>setNm(t.target.value)} />
                   
                </Form.Group>

                <Form.Group className="mb-3">
                    <Form.Label>Mobile</Form.Label>
                    <Form.Control id="t2" type="text" placeholder="Number" value={no} onChange={(t)=>setNo(t.target.value)}/>
                </Form.Group>
                <Form.Group className="mb-3" >
                    <Form.Label>Home</Form.Label>
                    <Form.Control id="t3" type="text" placeholder="Address" value={addr} onChange={(t)=>setAddr(t.target.value)}/>
                </Form.Group>
                <div className='login-link'>
                <Button variant="primary" type="submit" onClick={btn_click}>
                  Update Contact
                </Button>
                {/* <Link to={linkUrl}>View Update Contacts</Link> */}
                </div>
            </Form>
            </div>
            {/* {posts.nm}
            {posts.no}
            {posts.addr} */}
        </>
    )
}
export default Update_data