import { useState } from 'react';
import { Button , Form} from 'react-bootstrap';
import { Link,useNavigate  } from "react-router-dom";
const Login=()=>{
  const navigate = useNavigate();
    const [email,setEmail]=useState();
       const[pass,setPass]=useState();
     
    
       const btn_click=(event)=>{
       
        event.preventDefault();
       

         setEmail('');
         setPass('');
       

       fetch('http://bansiapp.atwebpages.com/match_data.php', {
      
                method: 'POST',
                body: JSON.stringify({
                  email:email,
                  pass:pass,
                
                }),
                headers: {
                  'Content-type': 'application/json; charset=UTF-8',
                },
              })
                .then((response) => response.json())
                .then((json) => {
                  navigate('/View/'+json.id);
                  console.log(json)
                });


                
       }
     


    return(
        <>
            <div className='main-div'>
              <h3>Login</h3>
            <Form>
                
                <Form.Group className="mb-3">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control id="t1" type="email" placeholder="Enter email" value={email} onChange={(t)=>setEmail(t.target.value)}/>
                   
                </Form.Group>

                <Form.Group className="mb-3">
                    <Form.Label>Password</Form.Label>
                    <Form.Control id="t2" type="password" placeholder="Password" value={pass} onChange={(t)=>setPass(t.target.value)}/>
                </Form.Group>
               
             
                <Button variant="primary" type="submit" onClick={btn_click}>
                   
                      Submit
                </Button>
               
            </Form>
            </div>
            <h5>{email}</h5>
            <h5>{pass}</h5>
           
        </>
    )
}
export default Login