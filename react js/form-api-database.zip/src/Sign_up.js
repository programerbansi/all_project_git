import { useState } from 'react';
import { Button , Form} from 'react-bootstrap';
import { Link } from "react-router-dom";
import './Sign_up.css'
const Sign_up = () => {
 
       const [email,setEmail]=useState();
       const[pass,setPass]=useState();
       const[cpass,setCpass]=useState();  
    
       const btn_click=(event)=>{
       
        event.preventDefault();
       

         setEmail('');
         setPass('');
         setCpass('');

         fetch('http://bansiapp.atwebpages.com/insert_data.php', {
      
                method: 'POST',
                body: JSON.stringify({
                  email:email,
                  pass:pass,
                  cpass:cpass
                }),
                headers: {
                  'Content-type': 'application/json; charset=UTF-8',
                },
              })
                .then((response) => response.json())
                .then((json) => console.log(json));


        
       }



    return (
        <><div className='main-div'>
              <h3>Sign up</h3>
            <Form>
                
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control id="t1" type="email" placeholder="Enter email" value={email} onChange={(t)=>setEmail(t.target.value)}/>
                   
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control id="t2" type="password" placeholder="Password" value={pass} onChange={(t)=>setPass(t.target.value)}/>
                </Form.Group>
                <Form.Group className="mb-3" controlId="formBasicPassword1">
                    <Form.Label>Confirm Password</Form.Label>
                    <Form.Control id="t3" type="password" placeholder="Confirm Password" value={cpass} onChange={(t)=>setCpass(t.target.value)}/>
                </Form.Group>
                {/* <Form.Group className="mb-3" controlId="formBasicCheckbox">
                    <Form.Check type="checkbox" label="Check me out" />
                </Form.Group> */}
                <div className='login-link'>
                <Button variant="primary" type="submit" onClick={btn_click}>
                    Submit
                </Button>
                <Link to="Login">Login Here</Link>
                </div>
            </Form>
            </div>
            {/* <h4> <Link to="View">View Submited Data</Link></h4> */}
            
        </>
    )
}
export default Sign_up