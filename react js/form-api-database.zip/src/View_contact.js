import { Link,useParams, useNavigate} from "react-router-dom";
import { Button , Form} from 'react-bootstrap';
import { useEffect , useState} from 'react';
const View_contact=()=>{
    
    let { id } = useParams();
    const navigate = useNavigate();
    console.log(id);
    const [posts,setPosts] = useState([])
   
    useEffect(()=>{
     
        fetch("http://bansiapp.atwebpages.com/insert_contact.php?id_no="+id)
          .then(res => res.json())
          .then(
            (r) => {
              console.log(r)
              setPosts(r)
            },
            
          )

        
       },[])

       const handleUpdate=(index)=>{
         alert("update"+index);
         fetch('http://bansiapp.atwebpages.com/select_data_update.php?id='+index)
          .then((response) => response.json())
          .then((json) => {
            navigate('/Update_data/'+json.id);
            // navigate('/View/'+json.id);
            console.log(json)
          });

         
       
       }
       const handleDelete=(index)=>{
         alert("delete"+index);
         fetch('http://bansiapp.atwebpages.com/delete_data.php', {
      
          method: 'POST',
          body: JSON.stringify({
            id:index
            
          }),
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
          },
        })
          .then((response) => response.json())
          .then((json) => {
            navigate('/View_contact/'+json.id);
            console.log(json)
          });

       }
    return(
        <>
        
       <table border="1">
                <thead><tr>
                 <td colSpan={5}> Contacts Detail of {id} number</td>
                  </tr>
                  <tr>
                    <th className="td_view_con">Id</th>
                    <th className="td_view_con">Id_No</th>
                    <th className="td_view_con">Name</th>
                    <th className="td_view_con">Mobile No.</th>
                    <th className="td_view_con">Address</th>
                    <th className="td_view_con"></th>
                  </tr>
                  </thead>
          {
          posts.map((item,index) => (
            <>
              
                <tbody>
                  <tr>
                    <td className="td_view_con">{item.id}</td>
                    <td className="td_view_con">{item.id_no}</td> 
                    <td className="td_view_con">{item.nm}</td>
                    <td className="td_view_con"> {item.no}</td>
                    <td className="td_view_con"> {item.addr}</td>
                    <td className="td_view_con">

                      <button onClick={()=>handleUpdate(item.id)}>Update</button>
                      <button onClick={()=>handleDelete(item.id)}>Delete</button>
                    </td>
                  </tr>
                </tbody>
         
             </>
             
          ))
          }
         </table>
        
        </>
    )
}
export default View_contact