import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import Sign_up from './Sign_up';
import { Routes, Route } from "react-router-dom"
import View from './View';
import Login from './Login';
import View_contact from './View_contact';
import Update_data from './Update_data';

function App() {
  return (
    <>
    {/* <Sign_up/> */}
    <Routes>
        <Route path="/" element={ <Sign_up/> } />
        <Route path="/View/:id" element={ <View/> } />
        <Route path="/Login" element={ <Login/> } />
        <Route path="/View_contact/:id" element={ <View_contact/> } />
        <Route path="/Update_data/:id" element={ <Update_data/> } />
      </Routes>
    </>
  )
}

export default App;
