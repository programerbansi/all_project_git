import { Card, Button, Badge } from 'react-bootstrap';
import { handeleClick } from './action/Action';
import './App.css';

import { Link } from "react-router-dom";
import { useDispatch, useSelector} from 'react-redux';
import Show from './reducer/Show';
import { useEffect, useState } from 'react';
const Home=()=>{
    const data=[
        {
          'name':'Good Vibes Rosehip Radiant Glow Face Serum',
          'image':require('./image/s1.jpg'),
          'price': '300',
          'fakeprice':'350',
          'offper':'5% Off'
        },
        {
          'name':'Neutrogena Ultra Sheer Dry-Touch Sunblock',
          'image':require('./image/s2.jpg'),
          'price': '400',
          'fakeprice':'500',
          'offper':'10% Off'
        },
        {
          'name':'Good Vibes Papaya Brightening Face Wash',
          'image':require('./image/s3.jpg'),
          'price': '400',
          'fakeprice':'450',
          'offper':'5% Off'
        },
        {
          'name':'Blue Heaven LASH TWIST Mascara(Water Proof)',
          'image':require('./image/s4.jpg'),
          'price': '260',
          'fakeprice':'300',
          'offper':'2% Off'
        },
        {
          'name':'Vitamin C Defying Face Serum',
          'image':require('./image/s5.jpg'),
          'price': '650',
          'fakeprice':'800',
          'offper':'20% Off'
        },
        {
          'name':'Mamaearth Ubtan Natural Face Wash',
          'image':require('./image/s6.jpg'),
          'price': '300',
          'fakeprice':'350',
          'offper':'5% Off'
        },
        {
          'name':'The Big Apple Of My Eye Kohl Stick',
          'image':require('./image/s7.jpg'),
          'price': '400',
          'fakeprice':'500',
          'offper':'10% Off'
        },
        {
          'name':'Good VibesSaffron Nourishing Day Cream',
          'image':require('./image/s8.jpg'),
          'price': '700',
          'fakeprice':'1000',
          'offper':'25% Off'
        },
        {
          'name':' Green Tea Glow Toner | Smoothing',
          'image':require('./image/s9.jpg'),
          'price': '460',
          'fakeprice':'520',
          'offper':'14% Off'
        },
        {
          'name':' Pink Roses Glow Toner | Smoothing',
          'image':require('./image/s10.jpg'),
          'price': '150',
          'fakeprice':'200',
          'offper':'5% Off'
        },
        {
          'name':'Radiant Glow Face Serum',
          'image':require('./image/s11.jpg'),
          'price': '800',
          'fakeprice':'1000',
          'offper':'20% Off'
        },
        {
          'name':'Heaven LASH TWIST Foundation(Water Proof)',
          'image':require('./image/s12.jpg'),
          'price': '200',
          'fakeprice':'240',
          'offper':'3% Off'
        },
        {
          'name':'White Glow Face Serum',
          'image':require('./image/z1.jpg'),
          'price': '600',
          'fakeprice':'750',
          'offper':'15% Off'
        },
        {
          'name':'Orange Face Cream',
          'image':require('./image/z2.jpg'),
          'price': '390',
          'fakeprice':'470',
          'offper':'4% Off'
        },
        {
          'name':'Green apple face cream',
          'image':require('./image/z3.jpg'),
          'price': '350',
          'fakeprice':'450',
          'offper':'10% Off'
        },
        {
          'name':'Rose Powder Makup',
          'image':require('./image/z4.jpg'),
          'price': '240',
          'fakeprice':'300',
          'offper':'5% Off'
        },
        {
          'name':'Coffe Face Pake',
          'image':require('./image/z5.jpg'),
          'price': '390',
          'fakeprice':'420',
          'offper':'7% Off'
        },
        {
          'name':'Face Glow Black Coffe creme',
          'image':require('./image/z6.jpg'),
          'price': '300',
          'fakeprice':'350',
          'offper':'5% Off'
        },
        {
          'name':'Green apple foundetion',
          'image':require('./image/z8.jpg'),
          'price': '400',
          'fakeprice':'550',
          'offper':'15% Off'
        },
        {
          'name':'Onion Oil and shmpoo',
          'image':require('./image/z9.jpg'),
          'price': '500',
          'fakeprice':'600',
          'offper':'10% Off'
        },
       
    
       
        
      ]; 
  const dispatch = useDispatch();
  

    return(
        <>
         <div>
         <Link to="/Show_carts" className='nav-link'>Carts
                
                 </Link> 
      </div>
      <div className="main">
                     

                         
                                {
                                      data.map((item,index)=>{
                                        return(
                                            <div className='div1'>
                                            <Card>
                                            <Card.Img variant="top" src={item.image} className='img1' />
                                            <Card.Body>
                                                <Card.Text>{item.name}</Card.Text>
                                                <Card.Text>
                                                    <span>₹ <b>{item.price}</b> <s>{item.fakeprice}</s> <span style={{ color: 'deeppink' }}>{item.offper}</span></span>
                                                </Card.Text>
                                                <Button className="btn1" onClick={()=>{dispatch(handeleClick(item))}}><span>ADD TO CART</span></Button>
  
                                            </Card.Body>
                                        </Card>
                                                </div>
                                        )
                                    })
                                }
      </div>
        </>
    )
}
export default Home