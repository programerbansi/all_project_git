export const handeleClick =(obj)=>{
    console.log('click');
    
    alert("add item in carts")
    return{
        type:'CLICK',
        payload:obj
    }
}