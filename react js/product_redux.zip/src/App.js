import { Card, Button, NavItem } from 'react-bootstrap';
import { handeleClick } from './action/Action';
import './App.css';
import { useDispatch, useSelector} from 'react-redux';
import Show from './reducer/Show';
import { useState } from 'react';
import Home from './Home';
import Show_carts from './Show_carts';
import { Routes, Route,useRoutes } from "react-router-dom"
import ClassDemo from './ClassDemo';
function App() {
    
    return(
      <>
      <Routes>
        <Route path="/" element={ <Home/> } />
        <Route path="Show_carts" element={ <Show_carts/> } />
      
      </Routes>
      </>
    )
   
}

export default App;
