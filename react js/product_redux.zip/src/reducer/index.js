import { combineReducers } from "redux";
import Show from "./Show";
const rootReducer = combineReducers({
    Show
})
export default rootReducer