const initial =[];
const Show=(state=initial,action)=>{
    switch(action.type)
    {
        case "CLICK":
            console.log(state)
            return [...state,action.payload]
        default:
            return state    
    }
}
export default Show