import { useSelector } from "react-redux"

import './Show_carts.css'
import { Link } from "react-router-dom";
const Show_carts=()=>{
    const no=useSelector((d)=>d.Show)
    console.log(no)
    return(
        <>
      
         <h1>Carts Items</h1>
         <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Price</th>
                <th>Fake Price</th>
                <th>Off per</th>
            </tr>
        {
            
            no.map((item)=>{
                return(
                    <>
                    
                        <tr>
                            <td><img src={item.image} width="50"></img></td>
                            <td>{item.name}</td>
                            <td>{item.price}</td>
                            <td>{item.fakeprice}</td>
                            <td>{item.offper}</td>
                        </tr>
                    </>
                )
            })
        }

         <h1><Link to="/" >Home</Link> </h1>

        </>
    )
}
export default Show_carts