import React, { Component } from 'react'

export default class ClassDemo extends Component {
    constructor(){
        super();
        this.state={
            'name':'CDMI',
            'city':'surat'
        }
        this.btnClick = this.btnClick.bind(this)
    }
     btnClick(){
        this.setState({'name':'Creative Multmiedia'})
    }
    componentDidMount(){
        console.log('component mounted');
    }
    componentDidUpdate(){
        console.log('updated')
    }
  render() {
    
    return (
      <div>
        <h1>Hello this is class-{this.state.name}</h1>
        <h1>City -{this.state.city}</h1>
        <button onClick={this.btnClick}>CLick me </button>
      </div>
    )
  }
}
