import React from "react";
//{ createContext } from "react";
const CartContext = React.createContext({});
export default CartContext;