const Login=()=>{
    return(
        <>
        <h1>login</h1>
        </>
    )
}
export default Login