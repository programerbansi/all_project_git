import { initializeApp } from "firebase/app";
import {getAuth} from 'firebase/auth';
import {getFirestore} from 'firebase/firestore'

const firebaseConfig = {
  apiKey: "AIzaSyBH3OCL1RQDIBj4WHEZQn9nCEB8ffJgcYY",
  authDomain: "react-firebase-auth-e504a.firebaseapp.com",
  projectId: "react-firebase-auth-e504a",
  storageBucket: "react-firebase-auth-e504a.appspot.com",
  messagingSenderId: "611217266769",
  appId: "1:611217266769:web:5fe4605c10ca5466d68070",
  measurementId: "G-KC4SKJVXSH"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
