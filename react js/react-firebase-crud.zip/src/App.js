import { Route, Routes } from 'react-router-dom';
import Login from './Components/Login'
import './App.css';
import SignUp from './Components/SignUp';
import Home from './Components/Home';
import Protected from './Components/Protected'
// https://codesandbox.io/s/vtull?file=/src/index.js := react-csv-reader
function App() {
  return (
    <div className="App">
      <Routes>
        <Route path='/' element={<Protected Component={Login}/>}/>
        <Route path='/signUp' element={<SignUp/>}/>
        <Route path='/home' element={<Home/>}/>
        <Route path='*' element={ <h1 className='text-center mt-4'> Error 404 Page not found !! </h1> }/>
      </Routes>
    </div>
  );
}

export default App;
