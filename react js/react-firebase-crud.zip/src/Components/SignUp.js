import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useForm } from 'react-hook-form';
import classNames from 'classnames';
import { auth } from '../firebase';
import {createUserWithEmailAndPassword} from 'firebase/auth';

function SignUp() {
    const navigate = useNavigate();
    const { register, handleSubmit, formState: { errors }, reset } = useForm();

    const onSubmit = (data) =>{
        createUserWithEmailAndPassword(auth,data.email,data.password).then((users)=>{
            console.log(users.user);
            navigate('/');
        }).catch((error)=>{
            console.log(error);
        })
        reset();
    }
    return (
        <div className=''>
            <div className="container">
                <div className='mb-5 pb-5'>
                    <section className="content">
                        <div className="container-fluid pt-5">
                            <div className="row justify-content-center">
                                <div className="col-md-6">
                                    <div className="card card-primary">
                                        <div className="card-header">
                                            <h3 className="card-title text-center">Sign Up</h3>
                                        </div>
                                        <form encType="multipart/form-data" onSubmit={handleSubmit(onSubmit)}>
                                            <div className="card-body">
                                                <div className="form-group text-start mb-3">
                                                    <label htmlFor="email">Email</label>
                                                    <input type="text" className={classNames("form-control", { 'is-invalid': errors.email })} id="email" placeholder="Email"
                                                        {...register("email", {
                                                            required: '** This field is required !!',
                                                            pattern: {
                                                                value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                                                                message: '** Invalid Email !!'
                                                            }
                                                        })}
                                                    />
                                                    {errors.email && (<span className='text-danger form-text invalid-feedback'>{errors.email.message}</span>)}
                                                </div>
                                                <div className="form-group text-start mb-3">
                                                    <label htmlFor="password">Password</label>
                                                    <input className={classNames("form-control", { 'is-invalid': errors.password })} id="password" placeholder="password" name='password'
                                                        {...register("password", {
                                                            required: '** This field is required !!',
                                                            pattern: {
                                                                value: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{6,}$/,
                                                                message: '** Minimum 6 characters, at least one letter and one number!!'
                                                            }
                                                        })} />
                                                    {errors.password && (<span className='text-danger form-text invalid-feedback'>{errors.password.message}</span>)}
                                                </div>
                                            </div>
                                            <div className="card-footer d-flex justify-content-between">
                                                <button className='btn btn-outline-primary px-4' type='submit'>Sign Up</button>
                                                <p className='text-end m-0'>Already have an account ? <NavLink to='/' className='text-decoration-none'>Login</NavLink></p>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    )
}

export default SignUp