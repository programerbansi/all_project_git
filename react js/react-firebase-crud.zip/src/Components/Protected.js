import React,{useEffect} from 'react'
import { useNavigate } from 'react-router-dom';

function Protected(props) {
    const navigate = useNavigate();
    const {Component} = props;

    let token = localStorage.getItem('LoginToken');
    useEffect(()=>{   
       if(token){
        navigate('/home')
       }
    })
    return (
        <div><Component/></div>
    )
}

export default Protected;