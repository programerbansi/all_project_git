import React, { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useForm } from 'react-hook-form';
import classNames from 'classnames';
import 'bootstrap/dist/css/bootstrap.min.css';
import {auth} from '../firebase'
import {signInWithEmailAndPassword} from 'firebase/auth';

function Login() {
    const navigate = useNavigate();

    const [error,setError] = useState('')
    const { register, handleSubmit, formState: { errors }, reset } = useForm({ mode: 'onTouched' });

    const onSubmit = (data) =>{
        console.log(data);
        
        signInWithEmailAndPassword(auth,data.email,data.password).then((useCrendential)=>{
            const user = useCrendential.user;
            console.log(user.accessToken,"===access token====");
            localStorage.setItem('LoginToken',user.accessToken);
            navigate('/home');
        }).catch((error)=>{
            console.log(error.message,"-----Error------");
            setError('User not found !');
        })
       setError('');
        reset();
    }
    return (
        <div className=''>
            <div className="container">
                <div className='mb-5 pb-5'>
                    <section className="content">
                        <div className="container-fluid pt-5">
                            <div className="row justify-content-center">
                                <div className="col-md-6">
                                    <div className="card card-primary">
                                        <div className="card-header">
                                            <h3 className="card-title text-center">Login</h3>
                                        </div>
                                        <form encType="multipart/form-data" onSubmit={handleSubmit(onSubmit)}>
                                            <div className="card-body">
                                                <div className="form-group text-start mb-3">
                                                    <label htmlFor="email">Email</label>
                                                    <input type="text" className={classNames("form-control", { 'is-invalid': errors.email })} id="email" placeholder="Email"
                                                        {...register("email", {
                                                            required: '** This field is required !!',
                                                            pattern: {
                                                                value: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
                                                                message: '** Invalid Email !!'
                                                            }
                                                        })}
                                                    />
                                                    {errors.email && (<span className='text-danger form-text invalid-feedback'>{errors.email.message}</span>)}
                                                </div>
                                                <div className="form-group text-start mb-3">
                                                    <label htmlFor="password">Password</label>
                                                    <input className={classNames("form-control", { 'is-invalid': errors.password })} id="password" placeholder="password" name='password'
                                                        {...register("password", {
                                                            required: '** This field is required !!',
                                                            pattern: {
                                                                value: /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{5,}$/,
                                                                message: '** Minimum eight characters, at least one letter and one number!!'
                                                            }
                                                        })} />
                                                    {errors.password && (<span className='text-danger form-text invalid-feedback'>{errors.password.message}</span>)}
                                                </div>
                                            </div>
                                            <div className="card-footer d-flex justify-content-between">
                                                <button className='btn btn-outline-primary px-4' type='submit'>Log In</button>
                                                <p className='text-center m-0'>Don't have an account ? <NavLink to='/signUp' className='text-decoration-none'> Sign Up</NavLink></p>
                                            </div>
                                        </form>
                                    </div>
                                    <span className='text-danger'>{error}</span>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    )
}

export default Login