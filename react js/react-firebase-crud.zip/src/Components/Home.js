import React, { useEffect, useState } from 'react';
import Header from './Header';
import 'bootstrap/dist/css/bootstrap.min.css';
import { useForm } from 'react-hook-form';
import classNames from 'classnames';
import { db } from '../firebase';
import { collection, getDocs, addDoc, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import ReactHTMLTableToExcel from 'react-html-table-to-excel';
import * as XLSX from 'xlsx';

import { CSVLink } from "react-csv";
import CSVReader from "react-csv-reader";

function Home() {
  const { register, handleSubmit, setValue, unregister, formState: { errors }, reset } = useForm();
  const [users, setUsers] = useState([]);
  const [editId, setEditId] = useState('');
  const usersCollectionRef = collection(db, 'users');
  const [data, setData] = useState([]);

  const onSubmit = (data) => {

    if (!editId) {
      const createUser = async () => {
        await addDoc(usersCollectionRef, { name: data.fname, age: Number(data.age) })
      }
      createUser();
    }
    else {
      const updateUser = doc(db, 'users', editId);
      const handleUpdate = async () => {
        await updateDoc(updateUser, { name: data.fname, age: Number(data.age) });
      }
      handleUpdate();
      setEditId('');
    }
    reset();
    const getUsers = async () => {
      const data = await getDocs(usersCollectionRef);
      setUsers(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })))
    }
    getUsers();
  }

  useEffect(() => {
    const getUsers = async () => {
      const data = await getDocs(usersCollectionRef);
      setUsers(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })))
    }
    getUsers();
  }, [])

  const handleDelete = async (id, index) => {
    const user = doc(db, 'users', id);
    await deleteDoc(user);
    users.splice(index, 1);
    setUsers([...users]);
  }

  const handleEdit = (id, user) => {
    setValue('fname', user.name);
    setValue('age', user.age);
    setEditId(id);
    unregister("fname");
    unregister("age");
  }

  const addFileData = ()=>{
    const createUser = async () => {
      for(let i=0 ; i<data.length;i++)
      {
        await addDoc(usersCollectionRef,{name:data[i].name, age: Number(data[i].age)});
        const getUsers = async () => {
          const data = await getDocs(usersCollectionRef);
          setUsers(data.docs.map((doc) => ({ ...doc.data(), id: doc.id })))
        }
        getUsers();
      }
    }
    createUser();
  }
  const handleForce = (data, fileInfo) => {
    console.log(data, fileInfo);
    setData(data);
  };
  const papaparseOptions = {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
    transformHeader: header => header.toLowerCase().replace(/\W/g, "_")
  };

  return (
    <div>
      <Header />
      <div className="container">
        <div className='mb-5 pb-5'>
          <section className="content">
            <div className="container-fluid pt-5">
              <div className="row justify-content-center">
                <div className="col-md-6">
                  <div className="card card-primary">
                    <div className="card-header">
                      <h4 className="card-title text-uppercase text-secondary">{editId ? 'Update User' : 'Add User'}</h4>
                    </div>
                    <form onSubmit={handleSubmit(onSubmit)}>
                      <div className="card-body">
                        <div className="form-group text-start mb-3">
                          <label htmlFor="fname">Name :</label>
                          <input type="text" className={classNames("form-control", { 'is-invalid': errors.fname })} id="fname" placeholder="Enter name"
                            {...register("fname", {
                              required: '** This field is required !!',
                              minLength: {
                                value: 3,
                                message: '** Name requires atleast 3 characters !!'
                              }
                            })}
                          />
                          {errors.fname && (<span className='text-danger form-text invalid-feedback'>{errors.fname.message}</span>)}
                        </div>
                        <div className="form-group text-start mb-3">
                          <label htmlFor="age">Age :</label>
                          <input type='number' className={classNames("form-control", { 'is-invalid': errors.age })} id="age" placeholder="Age"
                            name='age'
                            {...register("age", {
                              required: '** This field is required !!',
                              pattern: {
                                value: /^100|[1-9]?\d$/,
                                message: '** Enter valid age!!'
                              }
                            })} />
                          {errors.age && (<span className='text-danger form-text invalid-feedback'>{errors.age.message}</span>)}
                        </div>
                      </div>
                      <div className="card-footer">
                        <button className='btn btn-outline-primary' type='submit'>{editId ? 'Update User' : 'Add User'}</button>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
        <div className="row me-5">
          <div className="col-5 mb-4">
            <CSVReader
              cssClass="react-csv-input btn btn-outline-secondary"
              onFileLoaded={handleForce}
              parserOptions={papaparseOptions}
            />
            <button className='btn btn-outline-secondary ms-4' onClick={()=>addFileData()}>Add File Data</button>
          </div>
          <div className="col-5 offset-2">
            <CSVLink data={users} filename={"test.csv"} className='text-decoration-none btn btn-outline-success'>
              Download as CSV
            </CSVLink>
          </div>
        </div>

        <table className="table table-striped" id='user-table'>
          <thead>
            <tr>
              <th scope="col">Index</th>
              <th scope="col">Name</th>
              <th scope="col">Age</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {
              users.map((user, index) => {
                return <tr key={index}>
                  <th scope="row">{index + 1}</th>
                  <td>{user.name}</td>
                  <td>{user.age}</td>
                  <td>
                    <button className='btn btn-outline-primary' onClick={() => handleEdit(user.id, user)}>Edit</button>
                    <button className='btn btn-outline-danger ms-2' onClick={() => handleDelete(user.id, index)}>Delete</button>
                  </td>
                </tr>
              })
            }
          </tbody>
        </table>
      </div>
    </div>

  )
}

export default Home