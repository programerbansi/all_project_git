const Dashboard = () => {
    return (
        <>
            <div className="content-wrapper pt-3">
                <div className="container">
                    <h1>Dashboard</h1>
                </div>
            </div>
        </>
    )
}
export default Dashboard