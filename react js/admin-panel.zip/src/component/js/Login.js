import { Button, Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/Login.css'
import { FaBeer, FaUser } from 'react-icons/fa';
import { useState } from 'react';
const Login = () => {
    const [uname, setUname] = useState();
    const [pass, setPass] = useState();
    const [data, setData] = useState([]);

    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(uname + pass);
        setData([...data, { uname: uname, pass: pass }]);
    }
    return (
        <>
            <div className='container '>
                <div className='row '>
                    <div className='col-12'>
                     
                          <div className='parent'> 
                               <FaUser className='user-logo' />
                          </div>
                          <div className='sub-login p-3 parent'>
                            <Form>
                                <Form.Group className="mb-3" controlId="formBasicEmail">

                                    <Form.Control type="text" placeholder="Enter username" onChange={(e) => setUname(e.target.value)} />
                                </Form.Group>

                                <Form.Group className="mb-3" controlId="formBasicPassword">

                                    <Form.Control type="password" placeholder="Password" onChange={(e) => setPass(e.target.value)} />
                                </Form.Group>

                                <Button variant="primary" type="submit" onClick={() => handleSubmit()}>
                                    Sign In
                                </Button>
                            </Form>
                          
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}
export default Login