import { Route, Routes } from "react-router"
import Login from "../js/Login"
import Signup from "../js/Signup"
import Dashboard from "./Dashboard"


const Content = () => {
    return (
        <>
        <div className="content-main">
        <Routes>
        <Route path="/" element={<Dashboard/>} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Signup" element={<Signup />} />
        </Routes>
        </div>

        </>

    )
}
export default Content