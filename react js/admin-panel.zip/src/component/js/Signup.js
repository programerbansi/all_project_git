import { Button,Form } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/Signup.css'

const Signup=()=>{
  
    return(
        <>
         <div className='content-wrapper pt-5'>
            <div className='container'>
                <h3>Sign up</h3>
                <div className='sub-sign p-3'>
            <Form>
                <Form.Group className="mb-3" controlId="formBasicEmail">
                    <Form.Label>Email address</Form.Label>
                    <Form.Control type="email" placeholder="Enter email" />
                </Form.Group>

                <Form.Group className="mb-3" controlId="formBasicPassword">
                    <Form.Label>Password</Form.Label>
                    <Form.Control type="password" placeholder="Password" />
                </Form.Group>
              
                <Button variant="primary" type="submit">
                    Submit
                </Button>
            </Form>
          
            </div>
            </div>
            </div>

         
        </>
    )
}
export default Signup