import logo from './logo.svg';
import './App.css';
import Header from './component/js/Header';
import Sidebar from './component/js/Slidebar';
import Content from './component/js/Content';
import Footer from './component/js/Footer';
import Login from './component/js/Login';

function App() {
  return (
  
   <>
    <div class="wrapper">
      {/* <Login/> */}
      <Header/>
      <Sidebar/>
      <Content/>
      <Footer/>
   </div>
   </>
  );
}

export default App;
