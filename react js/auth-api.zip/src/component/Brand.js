import React,{useEffect} from "react"
import connect from 'react-redux'
import fatchBrand from '../Brand-Redux'
import { useDispatch } from 'react-redux'

const Brand = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(fatchBrand());
    },[])

    return(
        <div>
            
        </div>
    )
   
    // return userData.loading ? (
    //     <h2>Loading</h2>
    // ): userData.error ?(
    //     <h2>{userData.error}</h2>
    // ):(
    //     <div>
    //      <h2>user list</h2>
    //      {
    //         userData.map((user)=>{
    //             <p>{user.name}</p>
    //         })
    //     }
    //     </div>
    // )
}

// const mapStateToProps = state => {
//     return{
//         userData : state.user
//     }
// }

// const mapDispatchToProps = dispatch =>{
//     return{
//         fatchBrand: () => dispatch(fatchBrand())
//     }
// }


export default connect(mapDispatchToProps,mapStateToProps)(Brand)