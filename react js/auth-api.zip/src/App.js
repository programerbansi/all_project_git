import { Provider } from "react-redux";
import "./App.css";
import Brand from "./component/Brand";
const App = () => {
    return (
      <>
     
          <Brand/>
    
    
      </> 
    );
};

export default App;