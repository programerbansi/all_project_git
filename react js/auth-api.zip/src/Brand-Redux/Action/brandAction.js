import { FETCH_BRAND_FAILURE, FETCH_BRAND_REQUEST, FETCH_BRAND_SUCCESS } from "./brandTypes"
const axios = require('axios').default;
export const fetchBrandRequest = () =>{
    return{
        type: FETCH_BRAND_REQUEST
    }
}

export const fetchBrandSuccess = (brand) =>{
    return{
        type: FETCH_BRAND_SUCCESS,
        payload: brand
    }
}

export const fetchBranFailure = (error) =>{
    return{
        type: FETCH_BRAND_FAILURE,
        payload: error
    }
}


export const fetchBrand = () =>{
    
    return (dispatch) =>{
        dispatch(fetchBrandRequest);
        axios.get('https://jsonplaceholder.typicode.com/users')
         .then(response =>{
            const users = response.data;
            dispatch(fetchBrandSuccess(users))

         })
         .catch(error =>{
            const errorMsg = error.message
            dispatch(fetchBranFailure(errorMsg))
         })
    }
}