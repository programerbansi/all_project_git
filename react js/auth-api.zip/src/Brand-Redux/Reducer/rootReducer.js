import { combineReducers } from "redux";
import brandReducer from "./brandReducer"
const rootReducer = combineReducers({
    brand: brandReducer
})

export default rootReducer