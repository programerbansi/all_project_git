const initialState={
    loading: false,
    brand: [],
    error: ''
}

const reducer = (state=initialState, action) =>{

    switch(action.type)
    {
        case FATCH_BRAND_REQUEST:
            return{
                ...state,
                loading: true
            }

         case FATCH_BRAND_SUCCESS:
            return{
                loading: false,
                brand: action.payload,
                error:''
           }   
           
        case FATCH_BRAND_FAILURE:
            return{
                loading: false,
                brand: [],
                error:action.payload
            }

        default: return state    
    }
}

export default reducer